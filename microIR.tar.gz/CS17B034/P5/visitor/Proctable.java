 package visitor;
import java.util.*;
 class block{
  //in
  //out
  //use
  //def
  //succ
  //////All have temp ids but succ has statement ids in a procedure
  String pro;
  int Id;
  Set<Integer> In ;
  Set<Integer> oIn;
  Set<Integer> oOut;
  Set<Integer> Out ;
  Set<Integer> Use ;
  Set<Integer> Def ;
  Set <String> Succ;
  block(int id,String proc,Set<Integer> use,Set<Integer> def)
  {
  	Id = id;
  	pro=proc;
  	Use = use;
  	Def = def;
  	In = new HashSet<Integer>();
  	Out = new HashSet<Integer>();
  	oIn = new HashSet<Integer>();
  	oOut = new HashSet<Integer>();
  	Succ = new HashSet<String>();
  }

 }
 class liverange
 {
     int tempid;
     int st;
     int et;
     String reg;
     int spill;
     liverange(int t)
     {
       tempid = t;
       spill = -1;
       reg="";
     }
     void setst(int s)
     {
      st=s;
     }
     void setet(int e)
     {
      et=e;
     }
 }
 class Mycomp implements java.util.Comparator<liverange>
 {
    Mycomp()
    {
    
    }
    public int compare(liverange l1,liverange l2)
    {
       if(l1.st == l2.st)
       {
         return (l1.et - l2.et);
       }
       else return (l1.st - l2.st);
    }
 }
 class Mycomp1 implements java.util.Comparator<liverange>
 {
    Mycomp1()
    {
    
    }
    public int compare(liverange l1,liverange l2)
    {
       if(l1.et == l2.et)
       {
         return (l1.st - l2.st);
       }
       else return (l1.et - l2.et);
    }
 }
 class procedure
 {
  String name;
  int numarg;
  int stcount;
  Hashtable <Integer,block> states;
  Hashtable <String ,Integer > labelids;
  Hashtable <Integer,liverange> ranges;
  int maxarg;
  procedure(String proc,int narg)
  {
     name = proc;
     numarg = narg;
     stcount = -1000;
     maxarg=-1;
     states = new Hashtable <Integer,block>();
     labelids = new Hashtable <String , Integer>();
     ranges = new Hashtable <Integer,liverange>();
  }
  void livenessanaly()
  {
      //procedure p = pt.get(name);
      int iter=0;
      do{
      int i;
      iter=iter+1;
      //System.out.println(name);
      i=1;
      while(states.containsKey(i))
      {
        
        block b = states.get(i);
        (b.oIn).clear();
        b.oIn.addAll(b.In);
         (b.oOut).clear();
        b.oOut.addAll(b.Out);

        (b.Out).clear();
         
        for(String sid : b.Succ)
        {
          if(sid.charAt(0)=='L'){
             int id = labelids.get(sid);
           //  System.out.print(sid);
             //System.out.println(" "+sid);
             (b.Out).addAll(states.get(id).In);
             }
             else
             {
                if(states.containsKey(i+1)) (b.Out).addAll(states.get(i+1).In);
             }
        }

       // else (b.Out).clear();
      //  if(labelids.containsValue(i+1)) (b.Out).addAll(states.get(stcount).In);
       // System.out.println(b.Out);
        (b.In).clear();
        (b.In).addAll(b.Out);
       // System.out.print("Def");
        //System.out.println(b.Def);
        (b.In).removeAll(b.Def);
        (b.In).addAll(b.Use);
     // System.out.println(b.In);

       // System.out.println(b.oOut);

        states.put(i,b);  
        i=i+1;
                //System.out.println(p.states.get(i).In);
      }
      }
      while(!(checkinout()));
    //  System.out.println(iter);
      //pt.put(name,p);
  }
  boolean checkinout()
  {
  	Set<Integer> keys = states.keySet();
      Iterator<Integer> it = keys.iterator();
      int i;
      boolean t = true;
      while(it.hasNext())
      {
        i=it.next();
        block b =states.get(i);
       
        if(((b.In).equals(b.oIn)) && ((b.Out).equals(b.oOut))){}
        else
        {
           t=false;
           break;
        }
      }
      return t;
  }
  void printInOut()
  {
      Set<Integer> keys = states.keySet();
      Iterator<Integer> it = keys.iterator();
      int i;
      System.out.println(name);
      System.out.println(labelids);
      while(it.hasNext())
      {
        i=it.next();
        block b =states.get(i);
        System.out.println(b.Succ+"   "+Integer.toString(b.Id));
      }
      it = keys.iterator();
      while(it.hasNext())
      {
        i=it.next();
        block b =states.get(i);
        System.out.println(b.In+"   "+Integer.toString(b.Id));
      }
  }
  void liverangecalc()
  {
    Set<Integer> keys = states.keySet();
      Iterator<Integer> it = keys.iterator();
      int i=1;
      Set<Integer> cum = new HashSet<Integer>();
      while(states.containsKey(i))
      {
       block b = states.get(i);
        Set<Integer> temp = new HashSet<Integer>();
        temp.addAll(b.Def);
        //temp.removeAll(cum);
        for (Integer t : temp)
        {
            liverange l = new liverange(t);
            if(ranges.containsKey(t))
           {
             //ranges.get(t).setst(i);
           }
           else{
           l.setst(i);
           ranges.put(t,l);
           }
        }
        temp.clear();
        temp.addAll(b.In);
        //temp.removeAll(b.Out);
        for (Integer t : temp)
        {
            if(ranges.containsKey(t)){
            ranges.get(t).setet(i);
            //liverange l = ranges.get(t);
            }
            else
            {
              //liverange l = new liverange(t);
             //System.out.println(t);
                        
            }
           //System.out.println(Integer.toString(t)+"----range"+Integer.toString(l.st)+"  "+Integer.toString(l.et));
        }
        //cum=b.Out;
        i = i + 1;
      }
//      i = i - 1;
//      System.out.println(cum);
//      	for (Integer t : cum)
//        {
//            ranges.get(t).setet(i+1);
//            liverange l = ranges.get(t);
//            //System.out.println(Integer.toString(t)+"----range"+Integer.toString(l.st)+"  "+Integer.toString(l.et));
//        }
      //Set<Integer>ids = 
  }
  void linearscan()
  {
        ArrayList<liverange> active = new ArrayList<liverange>();
        ArrayList<liverange> spilled = new ArrayList<liverange>();
        ArrayList<String> freeregisterpool = new ArrayList<String>();
        for(int i=0;i<8;i++)
        {
         freeregisterpool.add("s"+Integer.toString(i));
        }
        for(int i=0;i<10;i++)
        {
         freeregisterpool.add("t"+Integer.toString(i));
        }
        int total_regs = 18;
        ArrayList<liverange> horiranges = new ArrayList<liverange>();
        for(Integer t : ranges.keySet())
        {
           if(ranges.get(t).et != 0) horiranges.add(ranges.get(t));
           else ranges.get(t).reg="v1";
        }
       // System.out.println("before");
        for(liverange l : horiranges)
        {
         //  System.out.println(Integer.toString(l.tempid) + " "+Integer.toString(l.st)+" "+Integer.toString(l.et));
        }
        Mycomp c = new Mycomp();
        Collections.sort(horiranges,c);
        /////AlGO Start
        //System.out.println("after");
       //System.out.println(name);
        for(liverange l : horiranges)
        {
           //System.out.println(Integer.toString(l.tempid) + " "+Integer.toString(l.st)+" "+Integer.toString(l.et));
           //ExpireOldIntervals
           Iterator<liverange> it = active.iterator();
           while(it.hasNext())
           {
             liverange a = it.next();
             if((a.et)< (l.st)) //////'=' means u can't'
             {
               it.remove();
               freeregisterpool.add(0,a.reg);
             }
     
           }
           if(active.size()==total_regs)
           {
            //SPILL
            //lastactive spill
            liverange s = active.get(active.size()-1);
            if (s.et > l.et)
            {
             l.reg = s.reg;
             s.reg="";
             spilled.add(s);
             s.spill=0;
             ranges.put(s.tempid,s);
                        //   System.out.println(Integer.toString(s.tempid)+"   --s-- "+s.reg);
             active.remove(active.indexOf(s));
             active.add(l);
             ranges.put(l.tempid,l);
                         //  System.out.println(Integer.toString(l.tempid)+"   ---- "+l.reg);
             Mycomp1 c2 = new Mycomp1();
             Collections.sort(active,c2);
            }
            else
            {
               spilled.add(l);
               l.spill=0;
               l.reg="";
               ranges.put(l.tempid,l);
            // System.out.println(Integer.toString(l.tempid)+"   --s-- "+l.reg);
            }
           }
           else
           {
              //System.out.println(freeregisterpool);
              String reg = freeregisterpool.get(0);
              freeregisterpool.remove(0);
              l.reg = reg;
         //   System.out.println(Integer.toString(l.tempid)+"   ---- "+l.reg);
              active.add(l);
             // System.out.println(l.spill);
              ranges.put(l.tempid,l);
              //System.out.println(ranges.get(l.tempid).spill);
              Mycomp1 c1 = new Mycomp1();
              Collections.sort(active,c1);
           }
        }
       // System.out.println(ranges);
  }
 }
 public class Proctable
 {
    Hashtable <String,procedure> table;
    public Proctable()
    {
       table = new Hashtable<String,procedure>();
    }

 }
 
