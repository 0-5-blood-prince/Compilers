import syntaxtree.*;
import visitor.*;
import java.io.*;

public class P5 {
   public static void main(String [] args) {
      try {
         Node root = new microIRParser(System.in).Goal();
        // System.out.println("Program parsed successfully");
         GJDepthFirst1<String, String> ST=new GJDepthFirst1<String, String>();
         root.accept(ST,""); // Your assignment part is invoked here.
         Proctable p = new Proctable();
         p = ST.gettable();
          GJDepthFirst2<String, Proctable> PR=new GJDepthFirst2<String, Proctable>();
          root.accept(PR,p);        
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 



