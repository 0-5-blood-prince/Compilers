package visitor;
import java.util.*;
public class Classtable
{
	LinkedHashMap<String,Class> classtb;
    public Classtable()
     {
        LinkedHashMap<String,Class> classtb = new LinkedHashMap<String,Class>();
      }
      public void Displaytable()
      {
         classtb.forEach((k,v)->
      {System.out.println(k);
       v.Vart.forEach((k3,v3)->
       	 {
       	 	System.out.println(k3+" "+v3);
       	 });
       v.methodht.forEach((k1,v1)->
       {
       	 System.out.println(k1);
       	 System.out.println(v1.rettype);
       	        	 System.out.println(v1.parsig);
       	       System.out.print("args --> ");
       	       System.out.println(v1.argt);
       	       System.out.println("vars-->");
       	 v1.Vart.forEach((k2,v2)->
       	 {
       	 	System.out.println(k2+" "+v2);
       	 });
       });
      });
      }
}
class Method
{
	String MethodSig;
	public String pc;
	String rettype;
	String parsig;
        LinkedHashMap<String, String> Vart;
        LinkedHashMap<String,String> argt;
        public Method(String m)
        {
           Vart = new LinkedHashMap<String, String>();
           argt = new LinkedHashMap<String, String>();
           MethodSig=m;
           pc=null;
           parsig=null;
        }
}
class Class
{
	String ClassSig;
	String pc;
	boolean isMain;
        LinkedHashMap<String,Method> methodht;
        LinkedHashMap<String, String> Vart;
        public Class(String c)
        {
          methodht = new LinkedHashMap<String,Method>();
          Vart = new LinkedHashMap<String, String>();
          ClassSig=c;
          isMain=false;
  
        }
}

