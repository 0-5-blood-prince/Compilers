import syntaxtree.*;
import visitor.*;
import java.io.*;
//import classtable.*;
public class B1{
   public static void main(String [] args) {
      try {
         	Node root = new MiniJavaParser(System.in).Goal();
         	         	//Node root1 = new MiniJavaParser(System.in).Goal();
       		// Node root = new MiniJavaParser(System.in).Goal();
         	
         	Classtable c =new Classtable();
                GJDepthFirst1<String, String> ST=new GJDepthFirst1<String, String>();
                root.accept(ST,""); // Your assignment part is invoked here.
                c = ST.gettable();
                //c.Displaytable();
               // GJDepthFirst2<String , Classtable > TC=new GJDepthFirst2<String ,Classtable>();
                //root.accept(TC,c);
                GJDepthFirst3<String , Classtable > IR=new GJDepthFirst3<String ,Classtable>();
                root.accept(IR,c);         
                //System.out.println("Program parsed successfully");
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
} 



